import random
import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':
    # Put the code for the plots here, you can use different functions for each
    # part
    data = np.load('data.npy').tolist()
    feature_vec = []
    w = np.array([0, 0])
    for i in range(100):
        y.append(data[i][1])
        data[i].insert(1,1)
        feature_vec.append([data[i][0], data[i][1]])
        
    theta_1, hist_1 = bgd_l2(feature_vec, y, w, 0.05, 0.1, 0.001, 50)
    plt.plot(range(1, 51), hist_1)
    plt.ylabel('f(w))
    plt.xlabel('Iterations')
    plt.title('GD: \neta = 0:05; delta = 0:1; lambda = 0:001; num_iter = 50)
    plt.show()