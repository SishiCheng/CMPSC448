import math
import random
import numpy as np

#data two dimensional numpy array with each row being a feature vector,(X)
#y one-dimensional numpy array of target values
#w one-dimensional numpy array corresponding to the weight vector (theta)
#eta learning rate (alpha) given when call
#lam are parameters of the objective function
def bgd_l2(data, y, w, eta, delta, lam, num_iter):
    
    m = len(data)
    history_fw = []
    new_w = np.array([[w[0]], [w[1]]])
    for T in range(num_iter):
        predictions = np.array([[0.0],[0.0]])
        for i in range(m):
            x = np.array([[data[i][0]], [data[i][1]]])
            bound = np.dot(np.transpose(new_w), x) - y[i]
            bound = bound[0][0]
            if delta <= bound:
                predictions += 2.0 * (bound - delta) * x
            elif delta >= bound:
                predictions += 2.0 * (bound + delta) * x

        gradient_sum = 0.0
        for i in range(m):
            x = np.array([[data[i][0]], [data[i][1]]])
            bound = np.dot(np.transpose(new_w), x) - y[i]
            bound = bound[0][0]
            if delta <= bound:
                gradient_sum += np.square(bound - delta)
            if delta >= bound:
                gradient_sum += np.square(bound + delta)
                
        history_fw.append((1/m) * gradient_sum + lam * np.square(np.linalg.norm(new_w))) 
        
        
        new_w = new_w - (1.0 * (eta/m) *predictions + 2 * lam * new_w)
    new_w = np.transpose(new_w)
    new_w = new_w[0]
        
    return new_w, history_fw

#data = np.load('data.npy').tolist()
#feature_vec = []
#for i in range(100):
#    y.append(data[i][1])
#    data[i].insert(1,1)
#    feature_vec.append([data[i][0], data[i][1]])
#theta, cost_history = bgd_l2(feature_vec, y, w, 0.05, 0.1, 0.001, 50)
#print(cost_history[-1])


                            
def sgd_l2(data, y, w, eta, delta, lam, num_iter, i=-1):
    return new_w, history_fw

