import random
import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':
    # Put the code for the plots here, you can use different functions for each
    # part
