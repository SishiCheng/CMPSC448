import math
import random
import numpy as np


def bgd_l2(data, y, w, eta, delta, lam, num_iter):
    return new_w, history_fw


def sgd_l2(data, y, w, eta, delta, lam, num_iter, i=-1):
    return new_w, history_fw
